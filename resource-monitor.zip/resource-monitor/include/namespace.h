// In�cio do "Include Guard" padr�o do C++.
// Isso previne erros de "defini��o m�ltipla" caso o arquivo seja inclu�do mais de uma vez.
// Se 'NAMESPACE_H' ainda n�o foi definido...
#ifndef NAMESPACE_H
// ...ent�o defina 'NAMESPACE_H'.
#define NAMESPACE_H

#include <string> // Necess�rio para usar 'std::string'.
#include <vector> // Necess�rio para usar 'std::vector'

// Estrutura que armazena informa��es sobre um namespace de um processo
// Define um tipo de dado personalizado (struct) para agrupar as informa��es de um namespace.
struct NamespaceInfo {
	// O tipo do namespace (ex: "net", "pid", "mnt").
	std::string type;
	// O identificador �nico do namespace (ex: "net:[4026531993]").
	std::string id;
};

// Fun��es principais
// Abaixo est�o as "declara��es" ou "prot�tipos" das fun��es.
// Isso informa ao compilador que essas fun��es existem em algum lugar (no .cpp).
// O "linking" (liga��o) conectar� esta declara��o com o c�digo real da fun��o.

void listNamespaces(int pid); // Declara��o da fun��o que lista namespaces de um PID espec�fico.
void compareNamespaces(int pid1, int pid2); // Declara��o da fun��o que compara os namespaces entre dois PIDs.
void findProcessesInNamespace(const std::string& nsType, const std::string& nsId); // Declara��o da fun��o que encontra todos os PIDs que pertencem a um namespace espec�fico.
void reportSystemNamespaces(); // Declara��o da fun��o que conta quantos namespaces �nicos de cada tipo existem no sistema.
void executarExperimentoIsolamento(); // Declara��o da fun��o que executa o "Experimento 2" (overhead e isolamento).
void reportProcessCountsPerNamespace(); // Declara��o da fun��o que conta quantos processos est�o em cada namespace �nico.
void gerarRelatorioGeralCompleto(); // Declara��o da fun��o que gera um relat�rio completo combinando outros relat�rios.

// Fim do bloco do "Include Guard" (#ifndef NAMESPACE_H).
#endif