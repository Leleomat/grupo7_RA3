﻿#include "cgroup.h"
#include "monitor.h"
#include "namespace.h"
#include <iostream>
#include <string>
#include <filesystem>
#include <fstream>
#include <cctype>
#include <vector>
#include <limits>
#include <algorithm>
#include <thread>
#include <chrono>
#include <set>
#include <unistd.h>
#include <iomanip>

namespace fs = std::filesystem;

struct ProcessInfo {
	int pid;
	std::string name;
};

bool processoExiste(int PID) {
	std::filesystem::path dir = "/proc/" + std::to_string(PID);
	return std::filesystem::exists(dir) && std::filesystem::is_directory(dir);
}

void salvarMedicoesCSV(const StatusProcesso& medicao, const calculoMedicao& calculado)
{

	//const std::string path = "docs/dados" + std::to_string(medicao.PID) +".csv";

	std::filesystem::path base = std::filesystem::current_path();
	base = base.parent_path().parent_path().parent_path();
	std::filesystem::path path = base / "docs" / ("dados" + std::to_string(medicao.PID) + ".csv");


	bool novo = !std::filesystem::exists(path) || std::filesystem::file_size(path) == 0;

	std::ofstream f(path, std::ios::app);
	if (!f) return;

	if (novo) {
		f << "timestamp,PID,utime,stime,threads,contextSwitchfree,contextSwitchforced,"
			"vmSize_kB,vmRss_kB,vmSwap_kB,minfault,mjrfault,bytesLidos,bytesEscritos,"
			"rchar,wchar,syscallLeitura,syscallEscrita,"
			"usoCPU_pct,usoCPUGlobal_pct,taxaLeituraDisco_KiB_s,taxaLeituraTotal_KiB_s,"
			"taxaEscritaDisco_KiB_s,taxaEscritaTotal_KiB_s\n";
	}

	// timestamp UTC
	std::time_t t = std::time(nullptr);
	std::tm tm;
	gmtime_r(&t, &tm);
	char ts[32];
	std::strftime(ts, sizeof(ts), "%Y-%m-%dT%H:%M:%SZ", &tm);

	f << ts << ","
		<< medicao.PID << ","
		<< medicao.utime << ","
		<< medicao.stime << ","
		<< medicao.threads << ","
		<< medicao.contextSwitchfree << ","
		<< medicao.contextSwitchforced << ","
		<< medicao.vmSize << ","
		<< medicao.vmRss << ","
		<< medicao.vmSwap << ","
		<< medicao.minfault << ","
		<< medicao.mjrfault << ","
		<< medicao.bytesLidos << ","
		<< medicao.bytesEscritos << ","
		<< medicao.rchar << ","
		<< medicao.wchar << ","
		<< medicao.syscallLeitura << ","
		<< medicao.syscallEscrita << ","
		<< calculado.usoCPU << ","
		<< calculado.usoCPUGlobal << ","
		<< calculado.taxaLeituraDisco << ","
		<< calculado.taxaLeituraTotal << ","
		<< calculado.taxaEscritaDisco << ","
		<< calculado.taxaEscritaTotal
		<< "\n";
}

std::vector<ProcessInfo> listarProcessos() {
	std::vector<ProcessInfo> lista;

	for (const auto& entry : fs::directory_iterator("/proc")) {
		if (!entry.is_directory()) continue;

		const std::string dir = entry.path().filename().string();
		if (!std::all_of(dir.begin(), dir.end(), ::isdigit)) continue;

		int pid = std::stoi(dir);
		std::ifstream cmdline("/proc/" + dir + "/comm");
		std::string nome;
		if (cmdline.good())
			std::getline(cmdline, nome);

		if (!nome.empty())
			lista.push_back({ pid, nome });
	}
	return lista;
}

int escolherPID() {
	std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

	auto processos = listarProcessos();

	std::cout << "\n\033[1;33m=================== Processos disponiveis ==================\033[0m\n";
	for (const auto& p : processos) {
		std::cout << "PID: " << std::left << std::setw(25) << p.pid << "\tNome: " << p.name << "\n";
	}

	int pid;
	bool valido = false;

	do {
		std::cout << "\nDigite o número do PID escolhido: ";
		std::cin >> pid;

		if (std::cin.fail()) {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Entrada inválida. Tente novamente.\n";
			continue;
		}

		for (const auto& p : processos) {
			if (p.pid == pid) {
				if (processoExiste(pid)) {
					valido = true;
					break;
				}
			}
		}

		if (!valido)
			std::cout << "PID não encontrado entre os processos listados.\n";

	} while (!valido);

	return pid;
}

void executarExperimentos() {
	CGroupManager manager;

	int sub = -1;
	do {
		std::cout << "\n\033[1;36m======================= EXPERIMENTOS =======================\033[0m\n";
		std::cout << "\n\033[1;33m========================== CGROUP ==========================\033[0m\n";
		std::cout << "\033[1m"; // deixa opções em negrito
		std::cout << " 1. Experimento nº3 – Throttling de CPU\n";
		std::cout << " 2. Experimento nº4 – Limite de Memória\n";
		std::cout << "\033[0m";
		std::cout << "\n\033[1;33m======================== NAMESPACE =========================\033[0m\n";
		std::cout << "\033[1m"; // deixa opções em negrito
		std::cout << " 3. Experimento nº2 - Isolamento via Namespaces\n";
		std::cout << "\033[0m";
		std::cout << "\n\033[1;33m======================== PROFILER ==========================\033[0m\n";
		std::cout << "\033[1m"; // deixa opções em negrito
		std::cout << " 4. Experimento nº1 - Overhead de Monitoramento\n";
		std::cout << " 5. Experimento nº5 - Limitação de I/O\n\n";
		std::cout << " 0. Voltar ao menu principal.\n";
		std::cout << " Escolha: ";
		std::cout << "\033[0m";
		std::cin >> sub;

		if (sub == 1) {
			manager.runCpuThrottlingExperiment();
		}
		else if (sub == 2) {
			manager.runMemoryLimitExperiment();
		}
		else if (sub == 3) {
			executarExperimentoIsolamento();
		}
		else if (sub == 4) {
			std::cout << "OPÇÃO AINDA NÃO IMPLEMENTADA.\n";
		}
		else if (sub == 5) {
			std::cout << "OPÇÃO AINDA NÃO IMPLEMENTADA.\n";
		}
		else if (sub != 0) {
			std::cout << "Opção inválida.\n";
		}

	} while (sub != 0);
}

void cgroupManager() {
	CGroupManager manager;

	std::cout << "\033[1;36m";
	std::cout << "\n============================================================\n";
	std::cout << "                         CGroup Manager                      \n";
	std::cout << "============================================================\n";
	std::cout << "\033[0m";

	std::string cgroupName = "exp_" + std::to_string(time(nullptr));
	std::cout << "Nome do cgroup experimental: " << cgroupName << ".\n";

	if (!manager.createCGroup(cgroupName)) {
		std::cerr << "Falha ao criar cgroup.\n";
		return;
	}

	int pid = escolherPID();
	if (!manager.moveProcessToCGroup(cgroupName, pid)) {
		std::cerr << "Falha ao mover o processo para o cgroup.\n";
		return;
	}

	double cores;
	std::cout << "Limite de CPU (em núcleos, ex: 0.5, 1.0, -1 para ilimitado): ";
	std::cin >> cores;
	manager.setCpuLimit(cgroupName, cores);

	size_t memBytes;
	std::cout << "Limite de memória (em bytes, ex: 1000000000): ";
	std::cin >> memBytes;
	manager.setMemoryLimit(cgroupName, memBytes);

	std::cout << "\n--- Relatório de uso ---\n";

	auto cpu = manager.readCpuUsage(cgroupName);
	if (cpu.count("usage_usec"))
		std::cout << "CPU total usada (µs): " << cpu["usage_usec"] << "\n";
	if (cpu.count("user_usec"))
		std::cout << "Tempo em modo usuário (µs): " << cpu["user_usec"] << "\n";
	if (cpu.count("system_usec"))
		std::cout << "Tempo em modo kernel (µs): " << cpu["system_usec"] << "\n";

	auto mem = manager.readMemoryUsage(cgroupName);
	if (mem.count("memory.current"))
		std::cout << "Memória atual (bytes): " << mem["memory.current"] << "\n";

	std::cout << "\nEstatísticas de BlkIO:\n";
	auto blk = manager.readBlkIOUsage(cgroupName);

	if (blk.empty()) {
		std::cout << "(sem atividade de I/O registrada)\n";
		return;
	}

	for (const auto& entry : blk) {
		if (entry.rbytes == 0 && entry.wbytes == 0 && entry.dbytes == 0)
			continue;

		std::cout << "  Device " << entry.major << ":" << entry.minor << "\n";

		auto fmtBytes = [](uint64_t b) {
			const char* suf[] = { "B", "KB", "MB", "GB", "TB" };
			int i = 0;
			double v = b;
			while (v > 1024 && i < 4) { v /= 1024; i++; }
			std::ostringstream oss;
			oss << std::fixed << std::setprecision(2) << v << " " << suf[i];
			return oss.str();
			};

		std::cout << "    Read:    " << fmtBytes(entry.rbytes)
			<< "  (" << entry.rios << " ops)\n";
		std::cout << "    Write:   " << fmtBytes(entry.wbytes)
			<< "  (" << entry.wios << " ops)\n";
		std::cout << "    Discard: " << fmtBytes(entry.dbytes)
			<< "  (" << entry.dios << " ops)\n\n";
	}
}

// =========================================
// FUNÇÃO PARA O Perfilador de Recursos
// =========================================
void resourceProfiler() {
entrada:
	int PID = escolherPID();
	double intervalo;

	std::cout << "\033[1;36m"; // ciano em negrito
	std::cout << "\n============================================================\n";
	std::cout << "                       Resource Profiler                     \n";
	std::cout << "============================================================\n";
	std::cout << "\033[0m"; // reseta as cores pro resto do texto


	while (true) {
		std::cout << "\nInsira o intervalo de monitoramento, em segundos: ";
		std::cin >> intervalo;
		bool flagInsert = true;

		if (std::cin.fail()) {
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			std::cout << "Entrada inválida. Tente novamente.\n";
			flagInsert = false;
		}
		if (flagInsert) {
			break;
		}
	}
	StatusProcesso medicaoAnterior;
	StatusProcesso medicaoAtual;
	medicaoAtual.PID = PID;
	bool flagMedicao = true;
	int contador = 0;

	while (true) {

		if (!(coletorCPU(medicaoAtual) && coletorMemoria(medicaoAtual) && coletorIO(medicaoAtual) && coletorNetwork(medicaoAtual))) {
			std::cout << "\nFalha ao acessar dados do processo\n";
			std::cout << "Reiniciando...\n";
			goto entrada;
		}
		else {
			//criação e atualização CSV
			calculoMedicao resultado;
			if (flagMedicao) {
				resultado.usoCPU = 0;
				resultado.usoCPUGlobal = 0;
				resultado.taxaLeituraDisco = 0;
				resultado.taxaLeituraTotal = 0;
				resultado.taxaEscritaDisco = 0;
				resultado.taxaEscritaTotal = 0;
				salvarMedicoesCSV(medicaoAtual, resultado);
			}

			if (flagMedicao) {
				std::cout << "Primeira medição detectada... \n";
				std::cout << "Dados e métricas serão mostrados a partir da segunda medição, por favor espere " << intervalo << " segundos... \n";
				flagMedicao = false;
			}
			else {

				//Calculo das métricas de CPU
				double tempoCPUAtual = medicaoAtual.utime + medicaoAtual.stime;
				double tempoCPUAnterior = medicaoAnterior.utime + medicaoAnterior.stime;
				double deltaCPU = tempoCPUAtual - tempoCPUAnterior;
				double usoCPU = (deltaCPU / intervalo) * 100;
				double usoCPUGlobal = usoCPU / (static_cast<double>(sysconf(_SC_NPROCESSORS_ONLN)));

				//Cálculo das métricas de I/O (em KB)
				double taxaleituraDisco = (static_cast<double>(medicaoAtual.bytesLidos - medicaoAnterior.bytesLidos) / intervalo) / 1024;
				double taxaleituraTotal = (static_cast<double>(medicaoAtual.rchar - medicaoAnterior.rchar) / intervalo) / 1024;
				double taxaEscritaDisco = (static_cast<double>(medicaoAtual.bytesEscritos - medicaoAnterior.bytesEscritos) / intervalo) / 1024;
				double  taxaEscritaTotal = (static_cast<double>(medicaoAtual.wchar - medicaoAnterior.wchar) / intervalo) / 1024;

				resultado.usoCPU = usoCPU;
				resultado.usoCPUGlobal = usoCPUGlobal;
				resultado.taxaLeituraDisco = taxaleituraDisco;
				resultado.taxaLeituraTotal = taxaleituraTotal;
				resultado.taxaEscritaDisco = taxaEscritaDisco;
				resultado.taxaEscritaTotal = taxaEscritaTotal;
				salvarMedicoesCSV(medicaoAtual, resultado);

				printf(
					"================================================================================\n"
					"|                                MEDIÇÃO (Processo %d)                          \n"
					"================================================================================\n"
					"| Intervalo de monitoramento: %3.2f segundos                                      |\n"
					"--------------------------------------------------------------------------------\n"
					"| CPU                      |            |\n"
					"-----------------------------------------\n"
					"| user_time(s)             | %-10.6f |\n"
					"| system_time(s)           | %-10.6f |\n"
					"| Uso por core (%%)         |  %-9.5f |\n"
					"| Uso relativo (%%)         |  %-9.5f |\n"
					"-----------------------------------------\n"
					"| Threads / ContextSwitch  |            |\n"
					"-----------------------------------------\n"
					"| Threads                  | %-10u |\n"
					"| voluntary_ctxt_switch    | %-10u |\n"
					"| nonvoluntary_ctxt_switch | %-10u |\n"
					"-----------------------------------------\n"
					"| Memória                  |            |\n"
					"-----------------------------------------\n"
					"| VmSize (kB)              | %-10lu |\n"
					"| VmRSS (kB)               | %-10lu |\n"
					"| VmSwap (kB)              | %-10lu |\n"
					"| minor faults             | %-10lu |\n"
					"| major faults             | %-10lu |\n"
					"-----------------------------------------\n"
					"| Syscalls                 |            |\n"
					"-----------------------------------------\n"
					"| leituras                 | %-10lu |\n"
					"| escritas                 | %-10lu |\n"
					"-----------------------------------------\n"
					"| Taxas (KiB/s)            |            |\n"
					"-----------------------------------------\n"
					"| Leitura disco            | %-10.6f |\n"
					"| Leitura total (rchar)    | %-10.6f |\n"
					"| Escrita disco            | %-10.6f |\n"
					"| Escrita total (wchar)    | %-10.6f |\n"
					"-----------------------------------------\n"
					"| Network                  |            |\n"
					"-----------------------------------------\n"
					"| Bytes em fila (TX)       | %-10lu  |\n"
					"| Bytes em fila (RX)       | %-10lu  |\n"
					"| Conexões ativas          | %-10u  |\n"
					"=========================================\n"
					"| Próxima medição em %3.2f segundos...    |\n"
					"=========================================\n\n\n\n\n",
					medicaoAtual.PID, intervalo,
					medicaoAtual.utime, medicaoAtual.stime, usoCPU, usoCPUGlobal,
					medicaoAtual.threads, medicaoAtual.contextSwitchfree, medicaoAtual.contextSwitchforced,
					medicaoAtual.vmSize, medicaoAtual.vmRss, medicaoAtual.vmSwap,
					medicaoAtual.minfault, medicaoAtual.mjrfault,
					medicaoAtual.syscallLeitura, medicaoAtual.syscallEscrita,
					taxaleituraDisco, taxaleituraTotal, taxaEscritaDisco, taxaEscritaTotal,
					medicaoAtual.bytesTxfila, medicaoAtual.bytesRxfila,
					medicaoAtual.conexoesAtivas,
					intervalo
				);

			}
			contador++;
			if (contador == 5) {
				int escolha;
				while (true) {
					std::cout << "Deseja encerrar o monitoramento? (1 -> sim/0 -> não): \n";
					std::cin >> escolha;
					bool flagInsert = true;
					if (std::cin.fail() || escolha > 1) {
						std::cin.clear();
						std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
						std::cout << "Entrada inválida. Tente novamente.\n";
						flagInsert = false;
					}
					if (flagInsert) {
						break;
					}
				}
				if (escolha == 1) {
					while (true) {
						std::cout << "Certo, você quer monitorar outro processo ou sair do resource profiler? (1 -> sair/0 -> outro processo): \n";
						std::cin >> escolha;
						bool flagInsert = true;
						if (std::cin.fail() || escolha > 1) {
							std::cin.clear();
							std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
							std::cout << "Entrada inválida. Tente novamente. \n";
							flagInsert = false;
						}
						if (flagInsert) {
							break;
						}
					}
					if (escolha == 0) {
						goto entrada;
					}
					else {
						break;
					}
				}
				else {
					std::cout << "O processo de PID: " << medicaoAtual.PID << " será monitorado por mais 5 ciclos... \n";
					contador = 0;
				}
			}
			medicaoAnterior = medicaoAtual;
			std::this_thread::sleep_for(std::chrono::duration<double>(intervalo));
		}
	}
}

// Define a função 'namespaceAnalyzer', que atuará como um sub-menu para todas as operações de namespace.
void namespaceAnalyzer() {
	int sub; // Variável para armazenar a escolha do sub-menu.
	do { // Inicia um loop 'do-while' que continuará até que o usuário escolha '0' (Voltar).
		std::cout << "\033[1;36m"; // Define a cor do texto para ciano em negrito (código ANSI).
		std::cout << "\n============================================================\n";
		std::cout << "                       Namespace Analyzer                    \n";
		std::cout << "============================================================\n";
		std::cout << "\033[0m"; // reseta as cores pro resto do texto
		std::cout << "\033[1m"; // deixa opções em negrito
		std::cout << " 1. Listar namespaces de um processo\n";
		std::cout << " 2. Comparar namespaces entre dois processos\n";
		std::cout << " 3. Procurar processos em um namespace especifico\n";
		std::cout << " 4. Relatório geral de namespaces\n";
		std::cout << " 0. Voltar ao menu inicial\n";
		std::cout << "------------------------------------------------------------\n";
		std::cout << "Escolha: ";
		std::cout << "\033[0m"; // Reseta as cores para a entrada do usuário.
		std::cin >> sub; // Lê a escolha do usuário e armazena em 'sub'.

		if (sub == 1) { // Se o usuário escolheu '1'
			// A função 'escolherPID' mostra uma lista de processos e retorna o PID escolhido pelo usuário
			int pid = escolherPID();
			listNamespaces(pid); // Chama a função para listar os namespaces do PID escolhido.
		}

		else if (sub == 2) { // Se o usuário escolheu '2'
			// A função 'listarProcessos' retorna um vetor ou lista de processos e seus nomes
			auto processos = listarProcessos();

			// Imprime um cabeçalho para a lista de processos
			std::cout << "\n\033[1;33m=================== Processos disponiveis ==================\033[0m\n";
			// Itera sobre a lista de processos e imprime o PID e o nome de cada um.
			for (const auto& p : processos) {
				std::cout << "PID: " << std::left << std::setw(25) << p.pid << "\tNome: " << p.name << "\n";
			}

			int pid1, pid2; // Variáveis para armazenar os dois PIDs a comparar.
			std::cout << "\nDigite os dois PIDs separados por espaço: ";
			std::cin >> pid1 >> pid2; // Lê os dois PIDs.
			compareNamespaces(pid1, pid2); // Chama a função de comparação.
		}

		else if (sub == 3) { // Se o usuário escolheu '3'
			std::cout << "\n\033[1;33m============== Tipos de Namespaces disponiveis =============\033[0m\n";
			// Define um vetor com os tipos de namespace conhecidos.
			std::vector<std::string> tipos = { "ipc", "mnt", "net", "pid", "user", "uts", "cgroup" };
			// Itera sobre o vetor e imprime cada tipo.
			for (const auto& t : tipos)
				std::cout << "- " << t << "\n";

			std::string tipo; // Variável para armazenar o tipo escolhido.
			std::cout << "\nDigite o tipo de namespace (ex: net): ";
			std::cin >> tipo; // Lê o tipo.

			std::cout << "\n Buscando namespaces do tipo '" << tipo << "'...\n";

			// Esta seção serve para ajudar o usuário, mostrando IDs de namespace válidos.
			// Cria um 'set' para armazenar os IDs únicos encontrados.
			std::set<std::string> idsDisponiveis;
			// Itera por todos os diretórios em /proc
			for (const auto& entry : std::filesystem::directory_iterator("/proc")) {
				std::string pidStr = entry.path().filename(); // Pega o nome do diretório
				// Verifica se o nome é composto apenas por dígitos (é um PID)
				if (!std::all_of(pidStr.begin(), pidStr.end(), ::isdigit)) continue;

				// Constrói o caminho para o arquivo de namespace (ex: /proc/123/ns/net)
				std::string nsPath = "/proc/" + pidStr + "/ns/" + tipo;
				char buf[256]; // Buffer para ler o link simbólico.
				// Tenta ler o link simbólico que representa o ID do namespace.
				ssize_t len = readlink(nsPath.c_str(), buf, sizeof(buf) - 1);
				if (len != -1) { // Se a leitura for bem-sucedida
					buf[len] = '\0'; // Adiciona o terminador nulo
					idsDisponiveis.insert(std::string(buf)); // Insere o ID no 'set' (ignora duplicatas).
				}
			}

			if (idsDisponiveis.empty()) { // Se nenhum namespace desse tipo foi encontrado
				std::cout << "Nenhum namespace desse tipo foi encontrado.\n";
				continue; // Volta ao início do loop do menu.
			}

			// Imprime os IDs de namespace que foram encontrados
			std::cout << "\n\033[1;33m=============== Namespaces disponiveis (" << tipo << ") ==============\033[0m\n";
			int count = 0; // Contador para limitar a saída
			for (const auto& id : idsDisponiveis) {
				std::cout << " " << ++count << ". " << id << "\n"; // Imprime o ID
				if (count >= 10) { // Limita a 10 para não poluir a tela
					std::cout << "... (mostrando apenas os 10 primeiros)\n";
					break; // Sai do loop de impressão
				}
			}

			std::string idEscolhido; // Variável para o ID alvo.
			// Pede ao usuário o número (ex: 4026531993), não o ID formatado (ex: net:[...]).
			std::cout << "\nDigite o valor exato do namespace (ex: 4026531993): ";
			std::cin >> idEscolhido; // Lê o ID.
			// Chama a função de busca com o tipo e o ID.
			findProcessesInNamespace(tipo, idEscolhido);
		}

		else if (sub == 4) { // Se o usuário escolheu '4'
			gerarRelatorioGeralCompleto(); // Chama a função que gera o relatório completo.
		}

		else if (sub == 0) { // Se o usuário escolheu '0'
			std::cout << "Voltando ao menu principal...\n"; // Imprime mensagem de saída.
		}

		else { // Se a escolha não foi 0, 1, 2, 3 ou 4
			std::cout << "Opção inválida!\n"; // Informa o usuário.
		}

	} while (sub != 0); // O loop continua enquanto 'sub' for diferente de 0.
}

// Esta é a função principal, o ponto de entrada do programa.
int main() {
	int opcao; // Variável para armazenar a escolha do menu principal.
	do { // Inicia o loop do menu principal.
		// Imprime o cabeçalho do menu (com código ANSI para sublinhado e vermelho).
		std::cout << "\n\033[0;4;31m===================== RESOURCE MONITOR =====================\033[0m\n";
		std::cout << "\033[1m"; // Deixa as opções em negrito.
		std::cout << " 1. Gerenciar Cgroups\n";
		std::cout << " 2. Analisar Namespaces\n";
		std::cout << " 3. Perfilador de Recursos\n";
		std::cout << " 4. Executar Experimentos\n";
		std::cout << " 0. Sair\n";
		std::cout << " Escolha: ";
		std::cin >> opcao; // Lê a escolha do usuário.
		std::cout << "\033[0m"; // Reseta as cores.

		switch (opcao) {
		case 1: // Se 'opcao' for 1
			cgroupManager(); // Chama a função do gerenciador de Cgroups.
			break; // Sai do 'switch'.

		case 2: // Se 'opcao' for 2
			namespaceAnalyzer(); // Chama a função do analisador de Namespaces.
			break; // Sai do 'switch'.

		case 3: { // Se 'opcao' for 3
			resourceProfiler(); // Chama a função do perfilador de recursos.
			break; // Sai do 'switch'.
		}

		case 4: { // Se 'opcao' for 4
			executarExperimentos(); // Chama a função que executa os experimentos.
			break; // Sai do 'switch'.
		}

		case 0: // Se 'opcao' for 0
			std::cout << "Encerrando...\n"; // Imprime mensagem de saída.
			break; // Sai do 'switch'.

		default: // Se 'opcao' não for nenhuma das anteriores
			std::cout << "Opção inválida!\n"; // Informa o usuário.
		}

	} while (opcao != 0); // O loop continua enquanto 'opcao' for diferente de 0.
}